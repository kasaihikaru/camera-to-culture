class Users::SessionsController < Devise::SessionsController
  # before_action :configure_sign_in_params, only: [:create]

  # GET /resource/sign_in
  # def new
  #   super
  # end

  # POST /resource/sign_in
  def create
    # super

    self.resource = warden.authenticate!(auth_options)
    set_flash_message!(:notice, :signed_in)
    sign_in(resource_name, resource)
    yield resource if block_given?

    if search_result_params[:redirect_client_id].present?
      redirect_to new_user_message_path(current_user.id, search_result_params[:redirect_client_id])
    elsif search_result_params[:rv_redirect_client_id].present?
      redirect_to new_event_path(id: search_result_params[:rv_redirect_client_id])
    else
      respond_with resource, location: after_sign_in_path_for(resource)
    end
  end

  # DELETE /resource/sign_out
  # def destroy
  #   super
  # end

  protected

  # If you have extra params to permit, append them to the sanitizer.
  # def configure_sign_in_params
  #   devise_parameter_sanitizer.permit(:sign_in, keys: [:attribute])
  # end
  def search_result_params
    params.require(:user).permit(:redirect_client_id, :rv_redirect_client_id)
  end
end
