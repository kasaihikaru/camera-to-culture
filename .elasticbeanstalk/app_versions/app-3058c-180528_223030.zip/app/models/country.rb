class Country < ApplicationRecord
	has_many :client_locations
end