class Language < ApplicationRecord
	has_many :user_languages
end