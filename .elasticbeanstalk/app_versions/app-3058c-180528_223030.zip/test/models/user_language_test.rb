require 'test_helper'

class UserLanguageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
