require 'test_helper'

class ClientReviewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
