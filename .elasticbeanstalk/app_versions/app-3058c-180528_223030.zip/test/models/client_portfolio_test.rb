require 'test_helper'

class ClientPortfolioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
