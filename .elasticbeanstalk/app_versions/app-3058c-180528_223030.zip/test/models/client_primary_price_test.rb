require 'test_helper'

class ClientPrimaryPriceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
