require 'test_helper'

class EventReviewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
