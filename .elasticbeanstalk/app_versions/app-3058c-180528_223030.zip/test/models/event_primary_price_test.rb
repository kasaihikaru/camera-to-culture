require 'test_helper'

class EventPrimaryPriceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
