require 'test_helper'

class ClientLocationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
