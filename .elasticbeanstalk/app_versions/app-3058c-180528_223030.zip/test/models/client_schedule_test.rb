require 'test_helper'

class ClientScheduleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
