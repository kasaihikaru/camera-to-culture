require 'test_helper'

class EventPhotoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
