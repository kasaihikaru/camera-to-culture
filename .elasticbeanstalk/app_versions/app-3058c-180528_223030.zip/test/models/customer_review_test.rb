require 'test_helper'

class CustomerReviewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
