require 'test_helper'

class ClientOptionPriceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
