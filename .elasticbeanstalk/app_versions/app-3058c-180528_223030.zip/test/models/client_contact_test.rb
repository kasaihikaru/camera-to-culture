require 'test_helper'

class ClientContactTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
